Authetication codes will be handed out by IT in the organization when signing up a few officer. Hard coded authentication code is currently 1234 
