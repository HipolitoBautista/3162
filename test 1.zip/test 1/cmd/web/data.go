package main

import "github.com/HipolitoBautista/internal/models"

type templateData struct {
	Form []*models.Form
}
