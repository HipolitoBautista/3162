INSERT INTO history(comments) 

VALUES
('First Comment Made'),
('Second comment Made');