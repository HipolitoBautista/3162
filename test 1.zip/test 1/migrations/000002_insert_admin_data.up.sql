INSERT INTO admin_users(email,au_password) 

VALUES
('hipbau11@gmail.com','pw123'),
('hipbau9394@gmail.com','pass234');