INSERT INTO public_user (email,pu_password)

VALUES 
('publicemail@gmail.com', 'pw385'),
('pubemail@gmail.com', 'passWorD');